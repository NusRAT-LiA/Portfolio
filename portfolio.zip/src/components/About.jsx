import React from "react";
import { motion } from "framer-motion";

import { styles } from "../styles";
import { SectionWrapper } from "../hoc";
import { fadeIn, textVariant } from "../utils/motion";



const About = () => {
  return (
    <>
      <motion.div variants={textVariant()}>
        <p className={styles.sectionSubText}>Introduction</p>
        <h2 className={styles.sectionHeadText}>Overview.</h2>
      </motion.div>

      <motion.p
        variants={fadeIn("", "", 0.1, 1)}
        className='mt-4 text-secondary text-[17px] max-w-3xl leading-[30px]'
      >
        I'm an aspiring software engineer and web3 enthusiast. I'm skilled in multiple programming
        languages including Solidity, Javascript, Java, Python, C, C++. I've worked on multiple projects and currently 
        focused on building a MARS-MISSION GAME and a DISTRIBUTED-SHIPMENT-CHAIN-IN-PORTS APPLICATION.
        I've been working with multiple non-profittable organizations and always willing to contribute to social causes.
        Fun fact is I'm also an artist, a debator, an instructor and also a writer !
      </motion.p>
      

    </>
  );
};

export default SectionWrapper(About, "about");
